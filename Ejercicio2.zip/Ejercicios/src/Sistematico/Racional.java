package Sistematico;

import java.util.Scanner;

public class Racional {
	
	private int numerador;
	private int denominador;
	public Racional() {
        numerador = 0;
        denominador = 1;
    }

    // Constructor parametrizado
    public Racional(int numerador, int denominador) {
        this.numerador = numerador;
        this.denominador = denominador;
    }

    // Accesor para el numerador
    public int getNumerador() {
        return numerador;
    }

    // Accesor para el denominador
    public int getDenominador() {
        return denominador;
    }

    // Método para leer los valores del numerador y denominador desde el teclado
    public void leer() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el numerador: ");
        numerador = scanner.nextInt();
        System.out.print("Ingrese el denominador: ");
        denominador = scanner.nextInt();
    }

    // Método para sumar dos números racionales
    public Racional suma(Racional otro) {
        int nuevoNumerador = (this.numerador * otro.denominador) + (otro.numerador * this.denominador);
        int nuevoDenominador = this.denominador * otro.denominador;
        return new Racional(nuevoNumerador, nuevoDenominador);
    }

    // Método para restar dos números racionales
    public Racional resta(Racional otro) {
        int nuevoNumerador = (this.numerador * otro.denominador) - (otro.numerador * this.denominador);
        int nuevoDenominador = this.denominador * otro.denominador;
        return new Racional(nuevoNumerador, nuevoDenominador);
    }

    // Método para multiplicar dos números racionales
    public Racional multiplicacion(Racional otro) {
        int nuevoNumerador = this.numerador * otro.numerador;
        int nuevoDenominador = this.denominador * otro.denominador;
        return new Racional(nuevoNumerador, nuevoDenominador);
    }

    // Método para dividir dos números racionales
    public Racional division(Racional otro) {
        int nuevoNumerador = this.numerador * otro.denominador;
        int nuevoDenominador = this.denominador * otro.numerador;
        return new Racional(nuevoNumerador, nuevoDenominador);
    }

    // Método para comparar dos números racionales
    public int comparar(Racional otro) {
        double resultado1 = (double) this.numerador / this.denominador;
        double resultado2 = (double) otro.numerador / otro.denominador;
        if (resultado1 < resultado2) {
            return -1;
        } else if (resultado1 > resultado2) {
            return 1;
        } else {
            return 0;
        }
    }

    // Método para hacer una copia de un número racional
    public Racional copia() {
        return new Racional(this.numerador, this.denominador);
    }

    // Método para imprimir el número racional
    public void print() {
        System.out.println(numerador + "/" + denominador);
    }

}
