package Sistematico;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Racional racional1 = new Racional(2, 3);
        Racional racional2 = new Racional(1, 4);

        // Realizar operaciones con los números racionales
        Racional suma = racional1.suma(racional2);
        Racional resta = racional1.resta(racional2);
        Racional multiplicacion = racional1.multiplicacion(racional2);
        Racional division = racional1.division(racional2);
        int comparacion = racional1.comparar(racional2);
        Racional copia = racional1.copia();

        // Imprimir los resultados
        System.out.print("Suma: ");
        suma.print();

        System.out.print("Resta: ");
        resta.print();

        System.out.print("Multiplicación: ");
        multiplicacion.print();

        System.out.print("División: ");
        division.print();

        System.out.println("Comparación: " + comparacion);

        System.out.print("Copia: ");
        copia.print();
    


	}

}
