package Ejrcicio2;


import java.util.Scanner;

public class Persona {
	Scanner tc= new Scanner(System.in);
	
	public String nombre;
	int edad;
	String DNI;
	String Genero;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
	public String getDNI() {
		return DNI;
	}
	public void setDNI(String dNI) {
		DNI = dNI;
	}
	
	public void PedDato1(String a, String b) {
		
		nombre=a;
		DNI=b;
		
	}
	
	public void gen() {
		
		if(edad>=18) {
			System.out.println("Es mayor de Edad");
		}else {
			System.out.println("Es menor de Edad");
		}
	}
	
	public void PedDato2() {
		System.out.println("Ingrese Edad: ");
		edad=tc.nextInt();
		
	}
	
	
	
	public void MaEd() {
		
		if(edad>=18) {
				System.out.println("Nombre: "+nombre+
						           "\nEdad: "+edad+
						           "\nDNI: "+DNI);
				System.out.println("Es mayor de Edad");
				
		}else {
			System.out.println("Es menor de Edad");
			System.out.println("No posee Cedula");
		}
	}
		
		
	
	
}
