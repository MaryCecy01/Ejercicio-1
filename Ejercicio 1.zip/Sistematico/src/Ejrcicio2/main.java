package Ejrcicio2;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Persona op= new Persona();
		String a="Ana Vasquez";
		String b="IS-6789-45M";
		
		op.PedDato1(a,b);
		op.PedDato2();
		op.MaEd();
	}

}
